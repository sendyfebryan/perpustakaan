<legend>Admin Mainpage</legend>

server
